import React, {useEffect, useState} from 'react'
import ReactPaginate from 'react-paginate';
import './ImgSearch.css';

export default function ImgSearch() {
    const [res, setRes] = useState([]);
    const [value, setValue] = useState('Flower');
    const [currentPage, setCurrentPage] = useState(1);
    const [totalpage, setTotalPage] = useState();
    
    const fetchImageData = () => {
      var url = `https://www.flickr.com/services/rest/?method=flickr.photos.search&api_key=636e1481b4f3c446d26b8eb6ebfe7127&tags=${value}&cur_page=${currentPage}&per_page=20&format=json&nojsoncallback=1`;
      fetch(url)
        .then(response => {
          return response.json()
        })
        .then(data => {
          setRes(data.photos.photo);
          setTotalPage(data.photos.pages);
        })   
    }

    if(value === ''){
        setValue('Flower');
    }
    
    useEffect(() => {
      fetchImageData();
    },[value,currentPage])

    const handlePageClick = (data) => {
        let page_no = data.selected + 1;
        setCurrentPage(page_no);
    }

    return (

      <div className='main-container'>
        <h1 className="text-dark fw-bolder my-4">ImagesStore</h1>
        <div className="container-fluid mb-4">
              <div className="row">
                  <div className="col-12 d-flex justify-content-center align-items-center">
                      <input
                      className="col-4 form-control-sm py-1 my-3  text-capitalize border border-3 border-dark"
                      type="text"
                      placeholder="Search Anything..."
                      onChange = { (e) => setValue(e.target.value)}
                      />
                  </div>                     
              </div>
        </div>

        <div className='my-2'>
            <button type="button" className="btn btn-dark mx-3" onClick={() => setValue('Mountain')}>Mountain</button>
            <button type="button" className="btn btn-dark mx-3" onClick={() => setValue('Beaches')}>Beaches</button>
            <button type="button" className="btn btn-dark mx-3" onClick={() => setValue('Birds')}>Birds</button>
            <button type="button" className="btn btn-dark mx-3" onClick={() => setValue('Food')}>Food</button>
        </div>

        <h2 className="text-dark fw-bolder my-4">{value} Pictures</h2>
        
        <div className="col-12 d-flex justify-content-evenly flex-wrap">
              {res.map(user => (
                  <div className='col-3 mb-3' key = {user.id}>
                          <img className='img-card' alt = 'storeimage' src = {`https://farm${user.farm}.staticflickr.com/${user.server}/${user.id}_${user.secret}_m.jpg`}  width="280" height="280"></img>
                          <button className="btn btn-dark my-3"><a href = {`https://farm${user.farm}.staticflickr.com/${user.server}/${user.id}_${user.secret}_m.jpg`} download= "xyz" style= {{color:'white'}}>Download</a></button>
                  </div>
              ))}
        </div>

        <ReactPaginate
          nextLabel="Next"
          previousLabel="Previous"             
          containerClassName="pagination d-flex justify-content-center align-items-center"
          breakClassName="page-item"
          breakLinkClassName="page-link"             
          activeClassName="active"
          onPageChange={handlePageClick}
          pageCount={totalpage}              
          pageClassName="page-item"
          pageLinkClassName="page-link"
          previousClassName="page-item"
          previousLinkClassName="page-link"
          nextClassName="page-item"
          nextLinkClassName="page-link"              
        />
      </div>

    );
    
}
