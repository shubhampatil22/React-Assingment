import './App.css';
import ImgSearch from './ImgSearch';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
  return (
    <div className="App">
      <ImgSearch/>
    </div>
  );
}

export default App;
